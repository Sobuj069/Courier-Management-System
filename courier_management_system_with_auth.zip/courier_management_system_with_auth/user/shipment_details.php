<?php
session_start();
include '../includes/db.php';

//  user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

// Get tracking number from URL
if (!isset($_GET['tracking'])) {
    echo "<div class='alert alert-warning'>No shipment specified.</div>";
    exit();
}
$tracking_number = $_GET['tracking'];

// Fetch shipment details
$stmt = $conn->prepare("SELECT * FROM shipments WHERE tracking_number = ?");
$stmt->bind_param("s", $tracking_number);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<div class='alert alert-warning'>Shipment not found.</div>";
    exit();
}

$shipment = $result->fetch_assoc();

// Permission check: users can only see their own shipments
if ($role === 'user' && $shipment['sender_id'] != $user_id) {
    echo "<div class='alert alert-danger'>Access denied. You can only view your own shipments.</div>";
    exit();
}

// Fetch status updates (if any)
$updates_stmt = $conn->prepare("SELECT * FROM status_updates WHERE shipment_id = ? ORDER BY changed_at DESC");
$updates_stmt->bind_param("i", $shipment['id']);
$updates_stmt->execute();
$updates_result = $updates_stmt->get_result();

include '../templates/header.php';
?>

<div class="container mt-4">
    <h2>Shipment Details - Tracking #: <?php echo htmlspecialchars($shipment['tracking_number']); ?></h2>
    <hr>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Shipment Information</strong>
        </div>
        <div class="card-body">
            <p><strong>Receiver Name:</strong> <?php echo htmlspecialchars($shipment['receiver_name']); ?></p>
            <p><strong>Receiver Phone:</strong> <?php echo htmlspecialchars($shipment['receiver_phone'] ?? 'N/A'); ?></p>
            <p><strong>Delivery Address:</strong> <?php echo nl2br(htmlspecialchars($shipment['address'])); ?></p>
            <p><strong>Weight:</strong> <?php echo htmlspecialchars($shipment['weight']); ?> kg</p>
            <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($shipment['description'] ?? 'N/A')); ?></p>
            <p><strong>Status:</strong> <span class="badge bg-info text-dark"><?php echo htmlspecialchars($shipment['status']); ?></span></p>
            <p><strong>Created At:</strong> <?php echo date('M d, Y H:i', strtotime($shipment['created_at'])); ?></p>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <strong>Status Updates</strong>
        </div>
        <div class="card-body">
            <?php if ($updates_result->num_rows > 0): ?>
                <ul class="list-group">
                    <?php while ($update = $updates_result->fetch_assoc()): ?>
                        <li class="list-group-item">
                            <strong><?php echo htmlspecialchars($update['new_status']); ?></strong> 
                            — <?php echo date('M d, Y H:i', strtotime($update['changed_at'])); ?><br>
                            <small><?php echo nl2br(htmlspecialchars($update['notes'] ?? '')); ?></small>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No status updates available.</p>
            <?php endif; ?>
        </div>
    </div>

    <a href="user_dashboard.php" class="btn btn-secondary mt-4">
        <i class="fas fa-arrow-left"></i> Back to Dashboard
    </a>
</div>

<?php include '../templates/footer.php'; ?>
