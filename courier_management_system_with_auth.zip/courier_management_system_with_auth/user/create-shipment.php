<?php
session_start();
include '../templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Shipment</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .shipment-container {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .form-control {
            margin-bottom: 15px;
            padding: 12px;
        }
        .btn-primary {
            width: 100%;
            padding: 12px;
            font-weight: 600;
        }
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .nav-buttons {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="shipment-container">
            <div class="header-container">
                <h2 class="mb-0">Create Shipment</h2>
                <div class="nav-buttons">
                    <a href="user_dashboard.php" class="btn btn-outline-primary">
                        <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                    </a>
                  
                </div>
            </div>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
            <?php endif; ?>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
            <?php endif; ?>

            <form action="../scripts/create_shipment.php" method="post" id="shipmentForm">
                <div class="form-group">
                    <label for="receiver_name" class="form-label">Receiver Name</label>
                    <input type="text" name="receiver_name" id="receiver_name" class="form-control" placeholder="Receiver Name" required>
                </div>

                <div class="form-group">
                    <label for="receiver_phone" class="form-label">Receiver Phone</label>
                    <input type="tel" name="receiver_phone" id="receiver_phone" class="form-control" placeholder="e.g. 123 456-7890" required>
                </div>

                <div class="form-group">
                    <label for="address" class="form-label">Delivery Address</label>
                    <textarea name="address" id="address" class="form-control" rows="3" placeholder="Delivery Address" required></textarea>
                </div>

                <div class="form-group">
                    <label for="weight" class="form-label">Weight (kg)</label>
                    <input type="number" name="weight" id="weight" class="form-control" step="0.01" min="0.1" placeholder="Weight in kilograms" required>
                </div>

                <div class="form-group">
                    <label for="description" class="form-label">Package Description</label>
                    <textarea name="description" id="description" class="form-control" rows="2" placeholder="Description of contents"></textarea>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary mt-3">
                        <i class="fas fa-truck me-2"></i> Create Shipment
                    </button>
                    <a href="user_dashboard.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Back to Dashboard
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const phoneInput = document.getElementById('receiver_phone');

    phoneInput.addEventListener('input', function (e) {
        const cleaned = e.target.value.replace(/\D/g, '');
        const match = cleaned.match(/^(\d{0,3})(\d{0,4})(\d{0,4})$/);

        if (!match) {
            e.target.value = cleaned;
            return;
        }

        if (!match[2]) {
            e.target.value = match[1];
        } else if (!match[3]) {
            e.target.value = match[1] + ' ' + match[2];
        } else {
            e.target.value = match[1] + ' ' + match[2] + '-' + match[3];
        }
    });

    document.getElementById('shipmentForm').addEventListener('submit', function (e) {
        const phone = phoneInput.value;
        // Regex for format: 3 digits + space + 4 digits + optional - + 4 digits
        const phoneRegex = /^\d{3} \d{4}(-\d{4})?$/;

        if (!phoneRegex.test(phone)) {
            e.preventDefault();
            alert('Please enter a valid phone number in the format: 017 1234-5678');
        }
    });
});
</script>


</body>
</html>

<?php include '../templates/footer.php'; ?>
