<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            background-color: #f4f6f9;
            padding: 20px;
        }
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .shipment-summary {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .shipment-table {
            margin-top: 30px;
        }
        .status-pending { color: #ffc107; font-weight: 600; }
        .status-in-transit { color: #0dcaf0; font-weight: 600; }
        .status-delivered { color: #198754; font-weight: 600; }
    </style>
</head>
<body>
<?php
session_start();
include '../includes/db.php';
include '../templates/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? 'User';

$query = "SELECT * FROM shipments WHERE sender_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container">
    <div class="dashboard-header">
        <h2>Welcome, <?php echo htmlspecialchars($name); ?>!</h2>
        <div>
            <a href="create-shipment.php" class="btn btn-success">
                <i class="fas fa-plus"></i> Create Shipment
            </a>
            <a href="../logout.php" class="btn btn-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <div class="shipment-summary">
        <h4 class="mb-3">Recent Shipments</h4>
        <?php if ($result->num_rows > 0): ?>
            <div class="table-responsive shipment-table">
                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>Tracking #</th>
                            <th>Receiver</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['tracking_number']); ?></td>
                                <td><?php echo htmlspecialchars($row['receiver_name']); ?></td>
                                <td class="status-<?php echo strtolower(str_replace(' ', '-', $row['status'])); ?>">
                                    <?php echo htmlspecialchars($row['status']); ?>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <a href="shipment_details.php?tracking=<?php echo urlencode($row['tracking_number']); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">No shipments found. <a href="create-shipment.php">Create one now</a>.</div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php include '../templates/footer.php'; ?>
