<?php
session_start();
include '../includes/db.php';

$email = $_POST['email'];
$password = md5($_POST['password']); // Consider bcrypt in future

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];

    // Redirect based on role
    if ($user['role'] === 'admin') {
        header("Location: ../admin/dashboard.php");
    } elseif ($user['role'] === 'agent') {
        header("Location: ../agent/assigned-shipments.php");
    } else {
        header("Location: ../user/User_Dashboard.php");
    }
    exit();
} else {
    echo "<script>alert('Invalid credentials'); window.location.href='../login.php';</script>";
}
$conn->close();
?>
