<?php
include '../includes/db.php';
$name = $_POST['name'];
$email = $_POST['email'];
$password = md5($_POST['password']);
$role = $_POST['role'];
$sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";
if ($conn->query($sql) === TRUE) {
  echo "<script>alert('Registered successfully!'); window.location.href='../login.php';</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>