<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized");
}

$user_id = $_SESSION['user_id'];

$receiver = $_POST['receiver_name'];
$phone = $_POST['receiver_phone'];
$address = $_POST['address'];
$weight = $_POST['weight'];
$description = $_POST['description'];
$tracking = uniqid('TRK');

// Insert all required fields
$sql = "INSERT INTO shipments (receiver_name, receiver_phone, address, weight, description, tracking_number, status, sender_id) 
        VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?)";
        
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssddsi", $receiver, $phone, $address, $weight, $description, $tracking, $user_id);

if ($stmt->execute()) {
    $_SESSION['success_message'] = "Shipment created successfully. Tracking ID: $tracking";
    header("Location: ../user/create-shipment.php");
    exit();
} else {
    $_SESSION['error_message'] = "Error creating shipment: " . $stmt->error;
    header("Location: ../user/create-shipment.php");
    exit();
}

$stmt->close();
$conn->close();
