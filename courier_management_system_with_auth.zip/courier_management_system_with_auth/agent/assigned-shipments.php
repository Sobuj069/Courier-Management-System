<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header("Location: ../login.php");
    exit();
}

include '../templates/header.php';

$agent_id = $_SESSION['user_id'];
$sql = "SELECT * FROM shipments WHERE assigned_agent_id = $agent_id ORDER BY created_at DESC";
$result = $conn->query($sql);

echo "<h2 class='text-xl font-semibold mb-4'>Assigned Shipments</h2>";

if ($result->num_rows > 0) {
    echo "<table class='table table-striped'>";
    echo "<tr><th>Tracking No</th><th>Receiver</th><th>Address</th><th>Status</th><th>Actions</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $tracking = htmlspecialchars($row['tracking_number']);
        echo "<tr>
                <td>{$tracking}</td>
                <td>" . htmlspecialchars($row['receiver_name']) . "</td>
                <td>" . htmlspecialchars($row['address']) . "</td>
                <td>" . htmlspecialchars($row['status']) . "</td>
                <td>
                    <a href='update_status.php?shipment_id={$row['id']}' class='btn btn-sm btn-primary me-1'>Update Status</a>
                    <a href='shipment_details.php?tracking={$tracking}' class='btn btn-sm btn-info'>View Details</a>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No shipments assigned yet.</p>";
}

echo "<a href='../logout.php' class='btn btn-danger mt-4'>Logout</a>";

include '../templates/footer.php';
?>
