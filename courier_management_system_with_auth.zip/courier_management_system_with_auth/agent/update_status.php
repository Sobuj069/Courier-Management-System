<?php
session_start();
include '../includes/db.php';

// Check agent login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'agent') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['shipment_id'])) {
    header("Location: assigned-shipments.php");
    exit();
}

$shipment_id = intval($_GET['shipment_id']);
$agent_id = $_SESSION['user_id'];

// Verify shipment belongs to agent
$sql = "SELECT * FROM shipments WHERE id = $shipment_id AND assigned_agent_id = $agent_id";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    echo "Shipment not found or you don't have permission.";
    exit();
}

$shipment = $result->fetch_assoc();
$previous_status = $shipment['status'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'];
    $note = $conn->real_escape_string($_POST['notes'] ?? '');

    // Update shipment status
    $update_sql = "UPDATE shipments SET status = '$new_status' WHERE id = $shipment_id";
    if ($conn->query($update_sql) === TRUE) {
        // Insert into status_updates log
        $log_sql = "INSERT INTO status_updates (shipment_id, previous_status, new_status, changed_by, notes) 
                    VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($log_sql);
        $stmt->bind_param("issis", $shipment_id, $previous_status, $new_status, $agent_id, $note);
        $stmt->execute();

        echo "<script>alert('Status updated successfully!'); window.location.href='assigned-shipments.php';</script>";
        exit();
    } else {
        echo "Error updating status: " . $conn->error;
    }
}

include '../templates/header.php';
?>

<h2 class="text-xl font-bold mb-4">Update Status for Shipment: <?php echo htmlspecialchars($shipment['tracking_number']); ?></h2>

<form method="POST">
    <label for="status" class="form-label">Status:</label>
    <select name="status" id="status" class="form-select" required>
        <?php
        $statuses = ['Pending', 'In Transit', 'Delivered'];
        foreach ($statuses as $status) {
            $selected = ($shipment['status'] === $status) ? 'selected' : '';
            echo "<option value='$status' $selected>$status</option>";
        }
        ?>
    </select>
    <br><br>
    <label for="notes" class="form-label">Notes (optional):</label><br>
    <textarea name="notes" id="notes" class="form-control" rows="3"></textarea>
    <br>
    <input type="submit" class="btn btn-primary" value="Update Status">
</form>

<a href="assigned-shipments.php" class="btn btn-secondary mt-3">Back to Shipments</a>

<?php include '../templates/footer.php'; ?>
