<?php
include 'templates/header.php';
?>
<h2 class="text-2xl font-bold mb-4">Signup</h2>
<form action="scripts/register.php" method="POST" class="space-y-3">
  <input type="text" name="name" placeholder="Full Name" class="form-control" required><br>
  <input type="email" name="email" placeholder="Email" class="form-control" required><br>
  <input type="password" name="password" placeholder="Password" class="form-control" required><br>
  <select name="role" class="form-select" required>
    <option value="user">User</option>
    <option value="agent">Agent</option>
    <option value="admin">admin</option>
  </select><br>
  <input type="submit" value="Register" class="btn btn-primary">
</form>
<?php include 'templates/footer.php'; ?>