<?php
include 'templates/header.php';
echo "<h1 class='text-center text-2xl font-bold'>Welcome to Courier Management System</h1>";
include 'templates/footer.php';
?>