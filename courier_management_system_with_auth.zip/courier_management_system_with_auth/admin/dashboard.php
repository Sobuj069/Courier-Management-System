<?php
session_start();
include '../includes/db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #0d6efd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .status-pending {
            color: #ffc107;
            font-weight: 500;
        }
        .status-in-transit {
            color: #0dcaf0;
            font-weight: 500;
        }
        .status-delivered {
            color: #198754;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-header">
            <div>
                <h2 class="text-xl font-semibold mb-0">Admin Dashboard</h2>
                <p class="text-muted mb-0">Welcome back, <?php echo $_SESSION['name'] ?? 'Admin'; ?></p>
            </div>
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['name'] ?? 'A', 0, 1)); ?>
                </div>
                <div>
                    <span class="fw-bold"><?php echo $_SESSION['name'] ?? 'Admin'; ?></span><br>
                    <small class="text-muted">Administrator</small>
                </div>
                <a href="../logout.php" class="btn btn-sm btn-danger ms-3">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <?php
        // Fetch all shipments
        $sql = "SELECT s.id, s.tracking_number, s.receiver_name, s.address, s.status, u.name AS sender_name, a.name AS agent_name
                FROM shipments s
                LEFT JOIN users u ON s.sender_id = u.id
                LEFT JOIN users a ON s.assigned_agent_id = a.id
                ORDER BY s.created_at DESC";
        $result = $conn->query($sql);
        ?>

        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">All Shipments</h3>
                <a href="create-shipment.php" class="btn btn-sm btn-success">
                    <i class="fas fa-plus me-1"></i> Add New Shipment
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php if ($result->num_rows > 0) : ?>
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Tracking No</th>
                                    <th>Receiver</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Sender</th>
                                    <th>Assigned Agent</th>
                                    <th>Actions</th>
                                    <th> view Details </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()) : ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['tracking_number']); ?></td>
                                        <td><?php echo htmlspecialchars($row['receiver_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['address']); ?></td>
                                        <td>
                                            <span class="status-<?php echo strtolower(str_replace(' ', '-', $row['status'])); ?>">
                                                <?php echo htmlspecialchars($row['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['sender_name'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($row['agent_name'] ?? 'Unassigned'); ?></td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="assign_agent.php?shipment_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-user-tag"></i> Assign
                                                </a>
                                                <a href="edit_shipment.php?shipment_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                       
                                            </div>
                                        </td>
                                        <td>       <a href="shipment_details.php?tracking=<?php echo urlencode($row['tracking_number']); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <div class="alert alert-info">No shipments found.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
        // Add any custom JavaScript here if needed
        document.addEventListener('DOMContentLoaded', function() {
            // You can add interactive features here
        });
    </script>
</body>
</html>

<?php
include '../templates/footer.php';
?>