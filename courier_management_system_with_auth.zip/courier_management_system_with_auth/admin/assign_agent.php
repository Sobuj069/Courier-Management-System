<?php
session_start();
include '../includes/db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get shipment ID from query parameter
if (!isset($_GET['shipment_id'])) {
    header("Location: dashboard.php");
    exit();
}

$shipment_id = intval($_GET['shipment_id']);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $agent_id = intval($_POST['agent_id']);

    // Update shipment with assigned agent
    $sql = "UPDATE shipments SET assigned_agent_id = $agent_id WHERE id = $shipment_id";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Agent assigned successfully!'); window.location.href='dashboard.php';</script>";
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

include '../templates/header.php';

// Fetch shipment info
$shipment_res = $conn->query("SELECT * FROM shipments WHERE id = $shipment_id");
if ($shipment_res->num_rows === 0) {
    echo "<p>Shipment not found.</p>";
    include '../templates/footer.php';
    exit();
}
$shipment = $shipment_res->fetch_assoc();

// Fetch all agents
$agents_res = $conn->query("SELECT id, name FROM users WHERE role = 'agent'");

?>

<h2 class="text-xl font-bold mb-4">Assign Agent for Shipment: <?php echo htmlspecialchars($shipment['tracking_number']); ?></h2>

<form method="POST">
    <label for="agent_id" class="form-label">Select Agent:</label>
    <select name="agent_id" id="agent_id" class="form-select" required>
        <option value="">-- Select Agent --</option>
        <?php
        while ($agent = $agents_res->fetch_assoc()) {
            echo "<option value='{$agent['id']}'>{$agent['name']}</option>";
        }
        ?>
    </select>
    <br><br>
    <input type="submit" class="btn btn-primary" value="Assign Agent">
</form>

<a href="dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>

<?php include '../templates/footer.php'; ?>
