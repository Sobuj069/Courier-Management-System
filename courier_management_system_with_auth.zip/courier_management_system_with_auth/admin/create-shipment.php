<?php
session_start();
include '../templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Shipment</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .shipment-container {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .form-control {
            margin-bottom: 15px;
            padding: 12px;
        }
        .btn-primary {
            width: 100%;
            padding: 12px;
            font-weight: 600;
        }
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="shipment-container">
            <div class="header-container">
                <h2 class="mb-0">Create Shipment</h2>
                <a href="../logout.php" class="btn btn-danger">
                    <i class="fas fa-sign-out-alt me-1"></i> Logout
                </a>
            </div>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
            <?php endif; ?>

            <form action="../scripts/create_shipment.php" method="post" id="shipmentForm">
                <div class="form-group">
                    <label for="receiver_name" class="form-label">Receiver Name</label>
                    <input type="text" name="receiver_name" id="receiver_name" placeholder="Receiver Name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="receiver_phone" class="form-label">Receiver Phone</label>
                    <input type="tel" name="receiver_phone" id="receiver_phone" placeholder="Receiver Phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="address" class="form-label">Delivery Address</label>
                    <textarea name="address" id="address" placeholder="Delivery Address" class="form-control" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="tracking_number" class="form-label">Tracking Number</label>
                    <div class="input-group">
                        <input type="text" name="tracking_number" id="tracking_number" placeholder="Tracking Number" class="form-control" required>
                        <button class="btn btn-outline-secondary" type="button" id="generateTracking">
                            <i class="fas fa-random"></i> Generate
                        </button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="weight" class="form-label">Weight (kg)</label>
                    <input type="number" name="weight" id="weight" placeholder="Weight in kilograms" class="form-control" step="0.01" min="0.1" required>
                </div>
                
                <div class="form-group">
                    <label for="description" class="form-label">Package Description</label>
                    <textarea name="description" id="description" placeholder="Description of contents" class="form-control" rows="2"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary mt-3">
                    <i class="fas fa-truck me-2"></i> Create Shipment
                </button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Generate tracking number
            document.getElementById('generateTracking').addEventListener('click', function() {
                const prefix = 'TRK';
                const randomNum = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
                const trackingNumber = prefix + randomNum;
                document.getElementById('tracking_number').value = trackingNumber;
            });
            
            // Phone number formatting
            const phoneInput = document.getElementById('receiver_phone');
            phoneInput.addEventListener('input', function(e) {
                const x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
                e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
            });
            
            // Form validation
            document.getElementById('shipmentForm').addEventListener('submit', function(e) {
                const phone = document.getElementById('receiver_phone').value;
                const tracking = document.getElementById('tracking_number').value;
                
                if (!phone.match(/^\(\d{3}\) \d{3}-\d{4}$/)) {
                    e.preventDefault();
                    alert('Please enter a valid phone number in (123) 456-7890 format');
                    return;
                }
                
                if (!tracking) {
                    e.preventDefault();
                    alert('Please generate or enter a tracking number');
                    return;
                }
            });
        });
    </script>
</body>
</html>

<?php include '../templates/footer.php'; ?>