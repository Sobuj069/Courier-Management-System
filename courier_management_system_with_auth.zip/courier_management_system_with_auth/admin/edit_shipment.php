<?php
session_start();
include '../includes/db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Check if shipment_id is provided
if (!isset($_GET['shipment_id']) || !is_numeric($_GET['shipment_id'])) {
    header("Location: admin_dashboard.php");
    exit();
}

$shipment_id = $_GET['shipment_id'];

// Fetch shipment details
$shipment_sql = "SELECT * FROM shipments WHERE id = ?";
$stmt = $conn->prepare($shipment_sql);
$stmt->bind_param("i", $shipment_id);
$stmt->execute();
$shipment_result = $stmt->get_result();

if ($shipment_result->num_rows === 0) {
    header("Location: admin_dashboard.php");
    exit();
}

$shipment = $shipment_result->fetch_assoc();

// Fetch all agents for dropdown
$agents_sql = "SELECT id, name FROM users WHERE role = 'agent'";
$agents_result = $conn->query($agents_sql);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tracking_number = $_POST['tracking_number'];
    $receiver_name = $_POST['receiver_name'];
    $address = $_POST['address'];
    $status = $_POST['status'];
    $assigned_agent_id = $_POST['assigned_agent_id'] ?: null;

    // Update query without receiver_phone
    $update_sql = "UPDATE shipments SET 
                  tracking_number = ?,
                  receiver_name = ?,
                  address = ?,
                  status = ?,
                  assigned_agent_id = ?
                  WHERE id = ?";
    
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssssii", 
        $tracking_number,
        $receiver_name,
        $address,
        $status,
        $assigned_agent_id,
        $shipment_id
    );
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Shipment updated successfully!";
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error_message = "Error updating shipment: " . $conn->error;
    }
}

include '../templates/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Shipment</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .edit-container {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .form-label {
            font-weight: 600;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-in-transit {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        .status-delivered {
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="edit-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="mb-0">Edit Shipment</h2>
                <a href="dashboard.php" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
                </a>
            </div>
            
            <?php if (isset($error_message)): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="tracking_number" class="form-label">Tracking Number</label>
                        <input type="text" class="form-control" id="tracking_number" name="tracking_number" 
                               value="<?php echo htmlspecialchars($shipment['tracking_number']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="Pending" <?php echo $shipment['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="In Transit" <?php echo $shipment['status'] === 'In Transit' ? 'selected' : ''; ?>>In Transit</option>
                            <option value="Delivered" <?php echo $shipment['status'] === 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="receiver_name" class="form-label">Receiver Name</label>
                    <input type="text" class="form-control" id="receiver_name" name="receiver_name" 
                           value="<?php echo htmlspecialchars($shipment['receiver_name']); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="address" class="form-label">Full Address</label>
                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo htmlspecialchars($shipment['address']); ?></textarea>
                </div>
                
                <div class="mb-4">
                    <label for="assigned_agent_id" class="form-label">Assign Agent</label>
                    <select class="form-select" id="assigned_agent_id" name="assigned_agent_id">
                        <option value="">-- Unassigned --</option>
                        <?php while ($agent = $agents_result->fetch_assoc()): ?>
                            <option value="<?php echo $agent['id']; ?>" 
                                <?php echo $agent['id'] == $shipment['assigned_agent_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($agent['name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Changes
                    </button>
                    <a href="dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
include '../templates/footer.php';
?>