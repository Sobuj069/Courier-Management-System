<?php
include 'templates/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-control {
            margin-bottom: 15px;
        }
        .btn-success {
            width: 100%;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2 class="text-2xl font-bold mb-4">Login</h2>
            <form action="scripts/login_process.php" method="POST" class="space-y-3" id="loginForm">
                <input type="email" name="email" placeholder="Email" class="form-control" required><br>
                <input type="password" name="password" placeholder="Password" class="form-control" required><br>
                <input type="submit" value="Login" class="btn btn-success">
            </form>
            <p class="mt-2">Don't have an account? <a href="signup.php" class="text-blue-600">Sign up here</a></p>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
       
            const email = this.elements['email'].value;
            const password = this.elements['password'].value;
            
            if (!email || !password) {
                e.preventDefault();
                alert('Please fill in all fields');
            }
            
         
        });
    </script>
</body>
</html>
<?php include 'templates/footer.php'; ?>